﻿using System.Configuration.Internal;
using System.Media;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NAudio.Wave;
using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public class AudioManager // skrz chatko
        {
            public void Play(string fileName)
            {
                string path = System.IO.Path.Combine(
                    AppDomain.CurrentDomain.BaseDirectory,
                    "audio",
                    fileName
                );
            }
        }

        AudioManager audio = new AudioManager();

        public MainWindow()
        {
            InitializeComponent();
        }

        public void Launch_Click(object sender, RoutedEventArgs e)
        {
            pozadi.Source = new BitmapImage(new Uri("pack://application:,,,/img/placeholder.png"));
            title_menu.Visibility = Visibility.Collapsed;
            audio.Play("intro.mp3");
        }

        public void Continue_Click(object sender, RoutedEventArgs e)
        {
            pause_menu.Visibility = Visibility.Collapsed;
        }

        public void Quit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        public void EscMenu_KeyPress(object sender, KeyEventArgs e)
        {
            if (title_menu.Visibility == Visibility.Collapsed)
            {
                if (e.Key == Key.Escape)
                {
                    pause_menu.Visibility = Visibility.Visible;
                }
            }
        }
    }
}